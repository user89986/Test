﻿using System;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Partners_import> _partners;
        private ObservableCollection<Partner_product_import> _partnersProducts;

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
            LoadPartnersProductData();

        }

        private void LoadData()
        {
            try
            {
                using (var context = new TestEntities())
                {
                    _partners = new ObservableCollection<Partners_import>(context.Partners_import.ToList());
                    dataGrid1.ItemsSource = _partners;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных партнеров: {ex.Message}");
            }
        }

        private void LoadPartnersProductData()
        {
            try
            {
                using (var context = new TestEntities())
                {
                    _partnersProducts = new ObservableCollection<Partner_product_import>(context.Partner_product_import.ToList());
                    dataGrid2.ItemsSource = _partnersProducts;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных продуктов партнеров: {ex.Message}");
            }
        }

        private void EditAddButton_Click(object sender, RoutedEventArgs e)
        {
            Partners_import partnerToEdit;

            if (dataGrid1.SelectedItem != null)
            {
                partnerToEdit = dataGrid1.SelectedItem as Partners_import;
            }
            else
            {
                partnerToEdit = new Partners_import();
            }

            Edit edit = new Edit(partnerToEdit);

            if (edit.ShowDialog() == true)
            {
                LoadData();
                LoadPartnersProductData();
            }
        }

        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                LoadData();
                LoadPartnersProductData();
            }
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Add addWindow = new Add();
            if (addWindow.ShowDialog() == true)
            {
                LoadData();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (dataGrid1.SelectedItem != null)
            {
                var partnerToDelete = dataGrid1.SelectedItem as Partners_import;

                try
                {
                    using (var context = new TestEntities())
                    {
                        var partner = context.Partners_import.Find(partnerToDelete.Id);
                        if (partner != null)
                        {
                            context.Partners_import.Remove(partner);
                            context.SaveChanges();
                            _partners.Remove(partnerToDelete);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении партнера: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите партнера для удаления.");
            }
        }


    }
}





