﻿using System;
using System.Linq;
using System.Text;
using System.Windows;

namespace WpfApp1
{
    public partial class Add : Window
    {
        public Add()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(PartnerTypeTextBox.Text))
                errors.AppendLine("Укажите тип партнера");
            if (string.IsNullOrWhiteSpace(PartnerNameTextBox.Text))
                errors.AppendLine("Укажите имя партнера");
            if (string.IsNullOrWhiteSpace(DirectorTextBox.Text))
                errors.AppendLine("Укажите директора");
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
                errors.AppendLine("Укажите почту");
            if (string.IsNullOrWhiteSpace(PhoneNumberTextBox.Text))
                errors.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(PartnerAddressTextBox.Text))
                errors.AppendLine("Укажите адрес партнера");
            if (string.IsNullOrWhiteSpace(InnTextBox.Text))
                errors.AppendLine("Укажите ИНН");
            if (string.IsNullOrWhiteSpace(RatingTextBox.Text))
                errors.AppendLine("Укажите рейтинг");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            var context = new TestEntities();

            // Определяем текущий максимальный Id и увеличиваем его на 1
            int maxId = context.Partners_import.Any() ? context.Partners_import.Max(p => p.Id) : 5;
            int newId = maxId + 1;

            var partnerToSave = new Partners_import
            {
                Id = newId,
                PartnerType = PartnerTypeTextBox.Text,
                PartnerName = PartnerNameTextBox.Text,
                Director = DirectorTextBox.Text,
                Email = EmailTextBox.Text,
                PhoneNumber = PhoneNumberTextBox.Text,
                PartnerAddress = PartnerAddressTextBox.Text,
                Inn = InnTextBox.Text,
                Rating = RatingTextBox.Text
            };

            context.Partners_import.Add(partnerToSave);
            context.SaveChanges();
            MessageBox.Show("Информация сохранена!");
            this.DialogResult = true;
        }
    }
}