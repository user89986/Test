﻿using System;
using System.Linq;
using System.Text;
using System.Windows;

namespace WpfApp1
{
    public partial class Edit : Window
    {
        private Partners_import _partner;

        public Edit(Partners_import partner)
        {
            InitializeComponent();
            _partner = partner;
            LoadPartnerData();
        }

        private void LoadPartnerData()
        {
            PartnerTypeTextBox.Text = _partner.PartnerType;
            PartnerNameTextBox.Text = _partner.PartnerName;
            DirectorTextBox.Text = _partner.Director;
            EmailTextBox.Text = _partner.Email;
            PhoneNumberTextBox.Text = _partner.PhoneNumber;
            PartnerAddressTextBox.Text = _partner.PartnerAddress;
            InnTextBox.Text = _partner.Inn;
            RatingTextBox.Text = _partner.Rating;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrEmpty(PartnerTypeTextBox.Text))
                errors.AppendLine("Укажите тип партнера");
            if (string.IsNullOrEmpty(PartnerNameTextBox.Text))
                errors.AppendLine("Укажите имя партнера");
            if (string.IsNullOrEmpty(DirectorTextBox.Text))
                errors.AppendLine("Укажите директора");
            if (string.IsNullOrEmpty(EmailTextBox.Text))
                errors.AppendLine("Укажите почту");
            if (string.IsNullOrEmpty(PhoneNumberTextBox.Text))
                errors.AppendLine("Укажите номер телефона");
            if (string.IsNullOrEmpty(PartnerAddressTextBox.Text))
                errors.AppendLine("Укажите адрес партнера");
            if (string.IsNullOrEmpty(InnTextBox.Text))
                errors.AppendLine("Укажите ИНН");
            if (string.IsNullOrEmpty(RatingTextBox.Text))
                errors.AppendLine("Укажите рейтинг");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            _partner.PartnerType = PartnerTypeTextBox.Text;
            _partner.PartnerName = PartnerNameTextBox.Text;
            _partner.Director = DirectorTextBox.Text;
            _partner.Email = EmailTextBox.Text;
            _partner.PhoneNumber = PhoneNumberTextBox.Text;
            _partner.PartnerAddress = PartnerAddressTextBox.Text;
            _partner.Inn = InnTextBox.Text;
            _partner.Rating = RatingTextBox.Text;

            try
            {
                using (var context = new TestEntities())
                {
                    if (_partner.Id == 0)
                    {
                        // Если Id равен 0, это новый объект, добавляем его в контекст
                        context.Partners_import.Add(_partner);
                    }
                    else
                    {
                        // Если Id не равен 0, это существующий объект, обновляем его
                        context.Partners_import.Attach(_partner);
                        context.Entry(_partner).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();
                }

                MessageBox.Show("Сохранено!");
                this.DialogResult = true;
            }
            catch
            {
               
                MessageBox.Show($"Ошибка");
            }
        }
    }
}